<#

.SYNOPSIS

  DigiCert TLM AWR post-enrollment script for Microsoft AD FS / WAP SSL certificate deployment.
.DESCRIPTION

  This script is intended to run as a DigiCert Trust Lifecycle Manager Agent

  Admin Web Request (AWR) post-enrollment script.
  It reads DC1_POST_SCRIPT_DATA, locates the issued PFX/P12 certificate file,

  imports it into LocalMachine\My, then configures AD FS or WAP to use it.
.AWR ARGS
  
  args[0] = Role

            ADFS_PRIMARY / ADFS_SECONDARY / WAP
  args[1] = FederationServiceName

            Example: wap.aiauat.com
  args[2] = RestartServices

            true / false
  args[3] = ReEstablishWapTrust

            true / false

            Only used for WAP role.
.EXPECTED AWR PAYLOAD EXAMPLE

  {

    "args":["ADFS_PRIMARY","wap.aiauat.com","true","false"],

    "certfolder":"D:\\2026Renew\\20260604\\wap.aiauat.com_pfx_2026_06_04_14_44_10",

    "files":["wap.aiauat.com.pfx","wap.aiauat.com_legacy.pfx"],

    "password":"12345678"

  }
.NOTES

  Run context must have local administrator rights.

  For ADFS_PRIMARY, the account must have permission to update AD FS configuration.

  For WAP trust re-establishment, domain admin / delegated credentials may be required.

#>
$ErrorActionPreference = "Stop"
# -----------------------------

# Safety switch

# -----------------------------

$LEGAL_NOTICE_ACCEPT = "true"
# -----------------------------

# Logging

# -----------------------------

$LogFile = "C:\ProgramData\DigiCert\AWR\adfs-wap-awr.log"
function Write-Log {

    param(

        [Parameter(Mandatory = $true)]

        [string]$Message,
        [string]$Level = "INFO"

    )
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

    $line = "$timestamp [$Level] $Message"
    $logDir = Split-Path -Parent $LogFile

    if (-not (Test-Path $logDir)) {

        New-Item -ItemType Directory -Path $logDir -Force | Out-Null

    }
    Add-Content -Path $LogFile -Value $line

    Write-Host $line

}
function Fail {

    param([string]$Message)
    Write-Log -Message $Message -Level "ERROR"

    throw $Message

}
# -----------------------------

# Decode AWR payload

# -----------------------------

function Get-AwrPayload {

    if ([string]::IsNullOrWhiteSpace($env:DC1_POST_SCRIPT_DATA)) {

        Fail "DC1_POST_SCRIPT_DATA environment variable is empty or missing."

    }
    try {

        $json = [System.Text.Encoding]::UTF8.GetString(

            [System.Convert]::FromBase64String($env:DC1_POST_SCRIPT_DATA)

        )
        Write-Log "Decoded DC1_POST_SCRIPT_DATA successfully."
        # Mask password before logging payload.

        $payloadForLog = $json | ConvertFrom-Json

        if ($null -ne $payloadForLog.password) {

            $payloadForLog.password = "********"

        }
        Write-Log ("Payload JSON: " + ($payloadForLog | ConvertTo-Json -Compress))
        return $json | ConvertFrom-Json

    }

    catch {

        Fail "Failed to decode or parse DC1_POST_SCRIPT_DATA. Error: $($_.Exception.Message)"

    }

}
function Get-ArgValue {

    param(

        [object]$Payload,

        [int]$Index,

        [string]$DefaultValue = ""

    )
    if ($null -eq $Payload.args) {

        return $DefaultValue

    }
    if ($Payload.args.Count -le $Index) {

        return $DefaultValue

    }
    if ([string]::IsNullOrWhiteSpace([string]$Payload.args[$Index])) {

        return $DefaultValue

    }
    return [string]$Payload.args[$Index]

}
# -----------------------------

# Locate PFX/P12 file

# -----------------------------

function Find-PfxFile {

    param([object]$Payload)
    if ([string]::IsNullOrWhiteSpace([string]$Payload.certfolder)) {

        Fail "Payload does not contain certfolder."

    }
    $certFolder = [string]$Payload.certfolder
    if (-not (Test-Path $certFolder)) {

        Fail "Certificate folder does not exist: $certFolder"

    }
    Write-Log "Certificate folder from payload: $certFolder"
    $candidateFiles = @()
    if ($null -ne $Payload.files) {

        foreach ($f in $Payload.files) {

            $fullPath = Join-Path $certFolder ([string]$f)
            if ($fullPath -match "\.(pfx|p12)$" -and (Test-Path $fullPath)) {

                $candidateFiles += [string]$fullPath

            }

        }

    }
    if (@($candidateFiles).Count -eq 0) {

        $candidateFiles = @(

            Get-ChildItem -Path $certFolder -Recurse -File |
            Where-Object { $_.Extension -match "^\.(pfx|p12)$" } |
            ForEach-Object { [string]$_.FullName }

        )

    }

    else {

        $candidateFiles = @($candidateFiles)

    }
    if (@($candidateFiles).Count -eq 0) {

        Write-Log "Listing files under certificate folder for troubleshooting:" "WARN"
        Get-ChildItem -Path $certFolder -Recurse -File | ForEach-Object {

            Write-Log "Found file: $($_.FullName), Size=$($_.Length)" "WARN"

        }
        Fail "No PFX/P12 file found in certificate folder: $certFolder. ADFS/WAP requires a certificate with private key."

    }
    # Prefer non-legacy PFX/P12 file.

    $preferredFiles = @(

        $candidateFiles | Where-Object { $_ -notmatch "_legacy\.(pfx|p12)$" }

    )
    if (@($preferredFiles).Count -gt 0) {

        $selectedFile = [string]$preferredFiles[0]

    }

    else {

        $selectedFile = [string]$candidateFiles[0]

    }
    if (@($candidateFiles).Count -gt 1) {

        Write-Log "Multiple PFX/P12 files found. Selected: $selectedFile"

    }

    else {

        Write-Log "Selected PFX/P12 file: $selectedFile"

    }
    if ([string]::IsNullOrWhiteSpace($selectedFile)) {

        Fail "Selected PFX/P12 file path is empty."

    }
    if (-not (Test-Path $selectedFile)) {

        Fail "Selected PFX/P12 file does not exist: $selectedFile"

    }
    return $selectedFile

}
# -----------------------------

# PFX password handling

# -----------------------------

function Get-PfxPassword {

    param(

        [object]$Payload

    )
    if ($null -ne $Payload -and -not [string]::IsNullOrWhiteSpace([string]$Payload.password)) {

        Write-Log "Using PFX password from AWR payload password field."

        return ConvertTo-SecureString ([string]$Payload.password) -AsPlainText -Force

    }
    if (-not [string]::IsNullOrWhiteSpace($env:DC1_PFX_PASSWORD)) {

        Write-Log "Using PFX password from DC1_PFX_PASSWORD environment variable."

        return ConvertTo-SecureString $env:DC1_PFX_PASSWORD -AsPlainText -Force

    }
    Fail "No PFX password found. AWR payload does not contain password and DC1_PFX_PASSWORD is not set."

}
# -----------------------------

# Import PFX

# -----------------------------

function Import-CertificatePfx {

    param(

        [Parameter(Mandatory = $true)]

        [string]$PfxPath,
        [Parameter(Mandatory = $true)]

        [securestring]$Password

    )
    if ([string]::IsNullOrWhiteSpace($PfxPath)) {

        Fail "PFX path is empty before Import-PfxCertificate."

    }
    if (-not (Test-Path $PfxPath)) {

        Fail "PFX file does not exist before import: $PfxPath"

    }
    Write-Log "Importing PFX into Cert:\LocalMachine\My: $PfxPath"
    $importParams = @{
        FilePath = $PfxPath
        CertStoreLocation = "Cert:\LocalMachine\My"
        Password = $Password
        Exportable = $true
    }
    $importedCerts = Import-PfxCertificate @importParams
    if ($null -eq $importedCerts) {

        Fail "Import-PfxCertificate returned null."

    }
    # Import-PfxCertificate may return chain certificates as well.

    # Select the leaf certificate that has private key.

    $leafCert = @($importedCerts) |
        Where-Object { $_.HasPrivateKey } |
        Select-Object -First 1
    if ($null -eq $leafCert) {

        Fail "No certificate with private key was returned after PFX import."

    }
    $thumbprint = ($leafCert.Thumbprint -replace "\s", "").ToUpperInvariant()
    Write-Log "Imported certificate subject: $($leafCert.Subject)"

    Write-Log "Imported certificate thumbprint: $thumbprint"

    Write-Log "Imported certificate serial number: $($leafCert.SerialNumber)"

    Write-Log "Imported certificate expires: $($leafCert.NotAfter)"
    if (-not $leafCert.HasPrivateKey) {

        Fail "Imported certificate does not have private key. ADFS/WAP requires private key."

    }
    return $thumbprint

}
# -----------------------------

# Grant private key read access

# -----------------------------

function Grant-PrivateKeyReadAccess {

    param(

        [Parameter(Mandatory = $true)]

        [string]$Thumbprint,
        [string[]]$Accounts

    )
    $cert = Get-ChildItem -Path "Cert:\LocalMachine\My" |
        Where-Object { ($_.Thumbprint -replace "\s", "").ToUpperInvariant() -eq $Thumbprint } |
        Select-Object -First 1
    if ($null -eq $cert) {

        Fail "Cannot find certificate in LocalMachine\My for thumbprint $Thumbprint"

    }
    if (-not $cert.HasPrivateKey) {

        Fail "Certificate $Thumbprint does not have a private key."

    }
    try {

        $rsaKey = [System.Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPrivateKey($cert)
        if ($null -eq $rsaKey) {

            Write-Log "Could not resolve RSA private key object. Skipping ACL update." "WARN"

            return

        }
        $keyName = $rsaKey.Key.UniqueName

        $keyPath = Join-Path $env:ProgramData "Microsoft\Crypto\RSA\MachineKeys\$keyName"
        if (-not (Test-Path $keyPath)) {

            Write-Log "Private key file not found at expected path: $keyPath. Skipping ACL update." "WARN"

            return

        }
        foreach ($account in $Accounts) {

            try {

                Write-Log "Granting read permission on private key to $account"
                $acl = Get-Acl $keyPath
                $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(

                    $account,

                    "Read",

                    "Allow"

                )
                $acl.AddAccessRule($rule)

                Set-Acl -Path $keyPath -AclObject $acl

            }

            catch {

                Write-Log "Failed to grant private key access to $account. Error: $($_.Exception.Message)" "WARN"

            }

        }

    }

    catch {

        Write-Log "Private key ACL update failed. Error: $($_.Exception.Message)" "WARN"

    }

}
# -----------------------------

# Configure AD FS Primary

# -----------------------------

function Configure-AdfsPrimary {

    param(

        [Parameter(Mandatory = $true)]

        [string]$Thumbprint

    )
    Import-Module ADFS -ErrorAction Stop
    Write-Log "Setting AD FS Service Communications certificate."

    Set-AdfsCertificate -CertificateType Service-Communications -Thumbprint $Thumbprint
    Write-Log "Setting AD FS SSL certificate."

    Set-AdfsSslCertificate -Thumbprint $Thumbprint
    Write-Log "AD FS certificate list after update:"

    Get-AdfsCertificate |
        Format-Table CertificateType, Thumbprint, IsPrimary, NotAfter -AutoSize |
        Out-String |
        ForEach-Object { Write-Log $_ }
    Write-Log "AD FS SSL certificate after update:"

    Get-AdfsSslCertificate |
        Format-List |
        Out-String |
        ForEach-Object { Write-Log $_ }

}
# -----------------------------

# Configure AD FS Secondary

# -----------------------------

function Configure-AdfsSecondary {

    param(

        [Parameter(Mandatory = $true)]

        [string]$Thumbprint

    )
    Import-Module ADFS -ErrorAction Stop
    Write-Log "Setting AD FS SSL certificate on secondary AD FS server."

    Set-AdfsSslCertificate -Thumbprint $Thumbprint
    Write-Log "AD FS SSL certificate after update:"

    Get-AdfsSslCertificate |
        Format-List |
        Out-String |
        ForEach-Object { Write-Log $_ }

}
# -----------------------------

# Configure WAP

# -----------------------------

function Configure-Wap {

    param(

        [Parameter(Mandatory = $true)]

        [string]$Thumbprint,
        [string]$FederationServiceName,
        [bool]$ReEstablishTrust

    )
    Import-Module WebApplicationProxy -ErrorAction Stop
    Write-Log "Setting Web Application Proxy SSL certificate."

    Set-WebApplicationProxySslCertificate -Thumbprint $Thumbprint
    if ($ReEstablishTrust) {

        if ([string]::IsNullOrWhiteSpace($FederationServiceName)) {

            Fail "FederationServiceName is required when ReEstablishWapTrust is true."

        }
        Write-Log "Re-establishing WAP trust for federation service: $FederationServiceName"

        Write-Log "Install-WebApplicationProxy may prompt for credentials if not running in a suitable context."
        $installWapParams = @{
            CertificateThumbprint = $Thumbprint
            FederationServiceName = $FederationServiceName
        }
        Install-WebApplicationProxy @installWapParams

    }

    else {

        Write-Log "Skipping Install-WebApplicationProxy because ReEstablishWapTrust is false."

    }

}
# -----------------------------

# Restart services

# -----------------------------

function Restart-AdfsRelatedServices {

    param([string]$Role)
    if ($Role -like "ADFS*") {

        $svc = Get-Service -Name adfssrv -ErrorAction SilentlyContinue
        if ($null -ne $svc) {

            Write-Log "Restarting adfssrv service."

            Restart-Service -Name adfssrv -Force

        }

        else {

            Write-Log "adfssrv service not found." "WARN"

        }

    }
    if ($Role -eq "WAP") {

        $apphost = Get-Service -Name apphostsvc -ErrorAction SilentlyContinue
        if ($null -ne $apphost) {

            Write-Log "Restarting apphostsvc service."

            Restart-Service -Name apphostsvc -Force

        }

        else {

            Write-Log "apphostsvc service not found." "WARN"

        }
        $adfsSvc = Get-Service -Name adfssrv -ErrorAction SilentlyContinue
        if ($null -ne $adfsSvc) {

            Write-Log "Restarting adfssrv service."

            Restart-Service -Name adfssrv -Force

        }

    }

}
# -----------------------------

# Final validation

# -----------------------------

function Validate-LocalCertificate {

    param(

        [Parameter(Mandatory = $true)]

        [string]$Thumbprint

    )
    Write-Log "Final local certificate check:"
    $cert = Get-ChildItem Cert:\LocalMachine\My |
        Where-Object { ($_.Thumbprint -replace "\s", "").ToUpperInvariant() -eq $Thumbprint } |
        Select-Object -First 1
    if ($null -eq $cert) {

        Fail "Final validation failed. Certificate $Thumbprint not found in LocalMachine\My."

    }
    $cert |
        Format-List Subject, Thumbprint, SerialNumber, NotAfter, HasPrivateKey |
        Out-String |
        ForEach-Object { Write-Log $_ }
    if (-not $cert.HasPrivateKey) {

        Fail "Final validation failed. Certificate $Thumbprint does not have private key."

    }

}
# -----------------------------

# Main

# -----------------------------

try {

    if ($LEGAL_NOTICE_ACCEPT -ne "true") {

        Fail "LEGAL_NOTICE_ACCEPT must be set to true before running this script."

    }
    Write-Log "========== ADFS/WAP AWR deployment started =========="
    $payload = Get-AwrPayload
    $role = (Get-ArgValue -Payload $payload -Index 0 -DefaultValue "ADFS_PRIMARY").ToUpperInvariant()

    $federationServiceName = Get-ArgValue -Payload $payload -Index 1 -DefaultValue ""

    $restartServicesText = Get-ArgValue -Payload $payload -Index 2 -DefaultValue "true"

    $reEstablishTrustText = Get-ArgValue -Payload $payload -Index 3 -DefaultValue "false"
    $restartServices = [System.Convert]::ToBoolean($restartServicesText)

    $reEstablishTrust = [System.Convert]::ToBoolean($reEstablishTrustText)
    Write-Log "Role: $role"

    Write-Log "FederationServiceName: $federationServiceName"

    Write-Log "RestartServices: $restartServices"

    Write-Log "ReEstablishWapTrust: $reEstablishTrust"
    if ($role -notin @("ADFS_PRIMARY", "ADFS_SECONDARY", "WAP")) {

        Fail "Invalid role: $role. Valid values: ADFS_PRIMARY, ADFS_SECONDARY, WAP."

    }
    $pfxPath = Find-PfxFile -Payload $payload

    Write-Log "PFX path returned by Find-PfxFile: $pfxPath"
    $pfxPassword = Get-PfxPassword -Payload $payload

    $thumbprint = Import-CertificatePfx -PfxPath $pfxPath -Password $pfxPassword
    # Common accounts. Adjust if your AD FS service runs under a gMSA or custom service account.

    Grant-PrivateKeyReadAccess -Thumbprint $thumbprint -Accounts @(

        "NT SERVICE\adfssrv",

        "NT AUTHORITY\NETWORK SERVICE"

    )
    switch ($role) {

        "ADFS_PRIMARY" {

            Configure-AdfsPrimary -Thumbprint $thumbprint

        }
        "ADFS_SECONDARY" {

            Configure-AdfsSecondary -Thumbprint $thumbprint

        }
        "WAP" {

            $wapParams = @{
                Thumbprint = $thumbprint
                FederationServiceName = $federationServiceName
                ReEstablishTrust = $reEstablishTrust
            }
            Configure-Wap @wapParams

        }

    }
    if ($restartServices) {

        Restart-AdfsRelatedServices -Role $role

    }

    else {

        Write-Log "Service restart skipped by argument."

    }
    Validate-LocalCertificate -Thumbprint $thumbprint
    Write-Log "========== ADFS/WAP AWR deployment completed successfully =========="

    exit 0

}

catch {

    Write-Log "Deployment failed: $($_.Exception.Message)" "ERROR"

    Write-Log "========== ADFS/WAP AWR deployment failed ==========" "ERROR"

    exit 1

}
